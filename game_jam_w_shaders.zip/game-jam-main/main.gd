extends Node

var flashlight_stats = {"power": 0.5, "radius": 100}
